#!/system/bin/sh

tinymix 48 86
tinymix 49 86